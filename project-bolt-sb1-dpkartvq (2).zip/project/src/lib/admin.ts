import { supabase } from './supabase';

export async function upgradeToPremium(userEmail: string, durationInDays = 30) {
  try {
    // Buscar o usuário pelo email
    const { data: user, error: userError } = await supabase
      .from('auth.users')
      .select('id')
      .eq('email', userEmail)
      .single();

    if (userError || !user) {
      throw new Error('Usuário não encontrado');
    }

    // Calcular a data de expiração
    const premiumUntil = new Date();
    premiumUntil.setDate(premiumUntil.getDate() + durationInDays);

    // Atualizar o perfil do usuário
    const { error: updateError } = await supabase
      .from('user_profiles')
      .update({
        is_premium: true,
        premium_until: premiumUntil.toISOString()
      })
      .eq('user_id', user.id);

    if (updateError) {
      throw updateError;
    }

    return { success: true, message: `Usuário ${userEmail} atualizado para premium com sucesso` };
  } catch (error: any) {
    console.error('Erro ao atualizar usuário:', error);
    return { success: false, message: error.message };
  }
}
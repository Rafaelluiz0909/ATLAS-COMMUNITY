import React from 'react';
import { Play, Clock, ExternalLink } from 'lucide-react';

interface Video {
  id: string;
  title: string;
  duration: string;
  thumbnail: string;
  url: string;
}

const videos: Video[] = [
  {
    id: '1',
    title: 'Aula 1 - Introdução às Estratégias',
    duration: '10:00',
    thumbnail: 'https://img.youtube.com/vi/psqbl-yarGM/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=psqbl-yarGM'
  },
  {
    id: '2',
    title: 'Aula 2 - Aprofundamento',
    duration: '15:00',
    thumbnail: 'https://img.youtube.com/vi/u1EHLdhnRUQ/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=u1EHLdhnRUQ'
  },
  {
    id: '3',
    title: 'Aula 3 - Técnicas Avançadas',
    duration: '12:00',
    thumbnail: 'https://img.youtube.com/vi/KcvVHtPKYZI/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=KcvVHtPKYZI'
  },
  {
    id: '4',
    title: 'Aula 4 - Estratégias Práticas',
    duration: '18:00',
    thumbnail: 'https://img.youtube.com/vi/Bb1uIkdvlPw/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=Bb1uIkdvlPw'
  }
];

export function VideoPlayer() {
  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-white mb-8">Aulas Exclusivas</h1>
        
        {/* Lista de Vídeos */}
        <div className="bg-gray-900 rounded-lg p-4">
          <div className="space-y-4">
            {videos.map((video) => (
              <a
                key={video.id}
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-4 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
              >
                <div className="flex gap-4">
                  <div className="relative flex-shrink-0">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-40 h-24 rounded object-cover"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 transition-opacity group-hover:opacity-0">
                      <Play className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-lg font-medium text-white truncate">
                        {video.title}
                      </h4>
                      <ExternalLink className="w-5 h-5 text-gray-400 flex-shrink-0" />
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{video.duration}</span>
                    </div>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
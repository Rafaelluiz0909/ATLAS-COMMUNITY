import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { LogOut, Crown } from 'lucide-react';
import { AtlasLogo } from './AtlasLogo';

interface UserProfile {
  is_premium: boolean;
  premium_until: string | null;
}

export function Layout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  async function fetchUserProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('user_profiles')
        .select('is_premium, premium_until')
        .eq('user_id', user.id)
        .single();

      setProfile(profile);
    } catch (error) {
      console.error('Erro ao buscar perfil:', error);
    }
  }

  function getDaysRemaining(): number | null {
    if (!profile?.premium_until) return null;
    const now = new Date();
    const premiumUntil = new Date(profile.premium_until);
    const diffTime = premiumUntil.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate('/login');
  }

  const daysRemaining = getDaysRemaining();

  return (
    <div className="min-h-screen bg-black">
      <nav className="bg-gray-900 border-b border-red-600">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/dashboard" className="flex items-center gap-2">
                <AtlasLogo className="h-8 w-8" />
                <span className="text-xl font-bold text-red-600">ATLAS COMMUNITY</span>
              </Link>
            </div>
            
            <div className="flex items-center space-x-4">
              {profile?.is_premium && (
                <div className="flex items-center gap-2">
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black px-3 py-1 rounded-full flex items-center gap-2">
                    <Crown size={16} />
                    <span className="font-bold text-sm">PRO</span>
                  </div>
                  {daysRemaining !== null && (
                    <span className="text-sm text-gray-300">
                      {daysRemaining} {daysRemaining === 1 ? 'dia' : 'dias'} restantes
                    </span>
                  )}
                </div>
              )}
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-gray-300 hover:text-red-500 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                <LogOut size={20} />
                Sair
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 px-4">
        {children}
      </main>
    </div>
  );
}
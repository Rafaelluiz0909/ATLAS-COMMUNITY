import React from 'react';

export function AtlasLogo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M50 10L90 80H10L50 10Z"
        fill="#EF4444"
        className="text-red-600"
      />
      <path
        d="M50 30L75 70H25L50 30Z"
        fill="#000000"
      />
    </svg>
  );
}
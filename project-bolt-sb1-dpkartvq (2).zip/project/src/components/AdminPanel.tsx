import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { User, Shield, Calendar, Mail } from 'lucide-react';

interface UserProfile {
  id: string;
  user_id: string;
  is_premium: boolean;
  premium_until: string | null;
  created_at: string;
  email?: string;
}

export function AdminPanel() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadUsers() {
      try {
        const { data: profiles, error: profilesError } = await supabase
          .from('user_profiles')
          .select('*');

        if (profilesError) throw profilesError;

        // Buscar emails dos usuários
        const { data: authUsers, error: authError } = await supabase
          .from('auth.users')
          .select('id, email');

        if (authError) throw authError;

        // Combinar os dados dos perfis com os emails
        const usersWithEmail = profiles.map(profile => ({
          ...profile,
          email: authUsers.find(user => user.id === profile.user_id)?.email
        }));

        setUsers(usersWithEmail);
      } catch (error: any) {
        console.error('Erro ao carregar usuários:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    loadUsers();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="text-red-600">Carregando...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-black text-white p-6">
        <div className="bg-red-600/20 border border-red-600 rounded p-4 text-red-500">
          Erro ao carregar usuários: {error}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-red-600 mb-2">Painel Administrativo</h1>
        <p className="text-gray-400">Total de usuários: {users.length}</p>
      </div>
      
      <div className="bg-gray-900 rounded-lg shadow-lg overflow-hidden border border-red-600">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-800">
            <thead className="bg-gray-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-red-500 uppercase tracking-wider">
                  <div className="flex items-center gap-2">
                    <Mail size={16} />
                    Email
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-red-500 uppercase tracking-wider">
                  <div className="flex items-center gap-2">
                    <Shield size={16} />
                    Status
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-red-500 uppercase tracking-wider">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    Premium Até
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-red-500 uppercase tracking-wider">
                  <div className="flex items-center gap-2">
                    <User size={16} />
                    Registrado em
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-800/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {user.email || 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.is_premium ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.is_premium ? 'Premium' : 'Básico'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {user.premium_until ? new Date(user.premium_until).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {new Date(user.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
                    Nenhum usuário cadastrado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
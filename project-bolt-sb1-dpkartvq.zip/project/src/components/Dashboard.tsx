import React, { useState } from 'react';
import { Dice6, BookOpen, School, TrendingUp, Target, Utensils as Extension, Crown, Users, Handshake, Table, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PremiumModal } from './PremiumModal';
import { supabase } from '../lib/supabase';

export function Dashboard() {
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [isPremium, setIsPremium] = useState(false);

  React.useEffect(() => {
    checkPremiumStatus();
  }, []);

  const checkPremiumStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('user_profiles')
        .select('is_premium')
        .eq('user_id', user.id)
        .single();

      setIsPremium(profile?.is_premium || false);
    } catch (error) {
      console.error('Erro ao verificar status premium:', error);
    }
  };

  const handlePremiumSuccess = () => {
    setIsPremium(true);
  };

  const Badge = ({ type }: { type: 'pro' | 'free' }) => (
    <span className={`absolute top-3 right-3 px-2 py-1 text-xs font-bold rounded ${
      type === 'pro' 
        ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-black' 
        : 'bg-gradient-to-r from-green-400 to-green-600 text-white'
    }`}>
      {type === 'pro' ? 'PRO' : 'FREE'}
    </span>
  );

  return (
    <div className="min-h-screen bg-black text-white">
      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* FREE Features */}
        <h2 className="text-2xl font-bold text-red-600 mb-8">Recursos Gratuitos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {/* Roleta IA */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="free" />
            <div className="flex items-center gap-4 mb-4">
              <Dice6 className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Roleta IA</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Descubra novas possibilidades com nossa roleta potencializada por IA
            </p>
            <a 
              href="https://t.me/CODIGOBETA_BOT" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            >
              Acessar Roleta
            </a>
          </div>

          {/* Sorteios de Bancas */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="free" />
            <div className="flex items-center gap-4 mb-4">
              <Target className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Sorteios de Bancas</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Análise estratégica e sorteios inteligentes das principais bancas
            </p>
            <a 
              href="https://www.instagram.com/hernandes_mentor?igsh=aTM5bjB2NnYzZ2Zh&utm_source=qr" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            >
              Ver Sorteios
            </a>
          </div>

          {/* Operação Conjunta */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="free" />
            <div className="flex items-center gap-4 mb-4">
              <Handshake className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Operação Conjunta</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Participe de operações coordenadas com outros membros
            </p>
            <a 
              href="https://www.instagram.com/hernandes_mentor?igsh=aTM5bjB2NnYzZ2Zh&utm_source=qr" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            >
              Participar
            </a>
          </div>

          {/* Mentoria */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="free" />
            <div className="flex items-center gap-4 mb-4">
              <BookOpen className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Mentoria</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Acelere seu desenvolvimento com mentoria personalizada
            </p>
            <a 
              href="https://futurodoigaming.online/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            >
              Conhecer Mentoria
            </a>
          </div>

          {/* Aulas */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="free" />
            <div className="flex items-center gap-4 mb-4">
              <School className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Aulas</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Conteúdo exclusivo para impulsionar seu conhecimento
            </p>
            <Link 
              to="/aulas"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            >
              Ver Aulas
            </Link>
          </div>
        </div>

        {/* PRO Features */}
        <h2 className="text-2xl font-bold text-red-600 mb-8">Recursos Premium</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Roleta IA Pro */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <Star className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Roleta IA Pro</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Versão avançada da roleta com recursos exclusivos
            </p>
            {isPremium ? (
              <button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                Acessar Roleta Pro
              </button>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>

          {/* Planilha de Auxílio */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <Table className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Planilha de Auxílio</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Ferramentas e planilhas para otimizar suas estratégias
            </p>
            {isPremium ? (
              <button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                Acessar Planilhas
              </button>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>

          {/* Extensões Roleta */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <Extension className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Extensões Roleta</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Amplie suas possibilidades com extensões exclusivas para a roleta
            </p>
            {isPremium ? (
              <button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                Explorar Extensões
              </button>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>

          {/* Aulas Premium */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <Crown className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Aulas Premium</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Conteúdo exclusivo e avançado para membros premium
            </p>
            {isPremium ? (
              <Link 
                to="/aulas-premium"
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
              >
                Acessar Aulas
              </Link>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>

          {/* Comunidade VIP */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <Users className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Comunidade VIP</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Conecte-se com membros exclusivos e acesse conteúdo especial
            </p>
            {isPremium ? (
              <a 
                href="https://chat.whatsapp.com/GIrsSdwJ8226jdxOjmDsws" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
              >
                Entrar na Comunidade
              </a>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>

          {/* Alavancagem */}
          <div className="group bg-gradient-to-br from-black to-red-900 p-6 rounded-lg border border-red-600 hover:border-red-400 transition-all duration-300 relative">
            <Badge type="pro" />
            <div className="flex items-center gap-4 mb-4">
              <TrendingUp className="w-8 h-8 text-red-500" />
              <h2 className="text-2xl font-bold">Alavancagem</h2>
            </div>
            <p className="text-gray-300 mb-4">
              Estratégias avançadas para maximizar seus resultados
            </p>
            {isPremium ? (
              <button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                Começar Agora
              </button>
            ) : (
              <button 
                onClick={() => setShowPremiumModal(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Seja Premium
              </button>
            )}
          </div>
        </div>
      </main>

      <PremiumModal
        isOpen={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
        onSuccess={handlePremiumSuccess}
      />
    </div>
  );
}
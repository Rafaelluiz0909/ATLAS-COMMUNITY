import React, { useState } from 'react';
import { Play, Clock, ChevronRight } from 'lucide-react';

interface Video {
  id: string;
  title: string;
  duration: string;
  thumbnail: string;
}

const videos: Video[] = [
  {
    id: 'psqbl-yarGM',
    title: 'Aula 1 - Introdução às Estratégias',
    duration: '10:00',
    thumbnail: `https://img.youtube.com/vi/psqbl-yarGM/maxresdefault.jpg`
  },
  {
    id: 'u1EHLdhnRUQ',
    title: 'Aula 2 - Aprofundamento',
    duration: '15:00',
    thumbnail: `https://img.youtube.com/vi/u1EHLdhnRUQ/maxresdefault.jpg`
  },
  {
    id: 'KcvVHtPKYZI',
    title: 'Aula 3 - Técnicas Avançadas',
    duration: '12:00',
    thumbnail: `https://img.youtube.com/vi/KcvVHtPKYZI/maxresdefault.jpg`
  },
  {
    id: 'Bb1uIkdvlPw',
    title: 'Aula 4 - Estratégias Práticas',
    duration: '18:00',
    thumbnail: `https://img.youtube.com/vi/Bb1uIkdvlPw/maxresdefault.jpg`
  }
];

export function VideoPlayer() {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(videos[0]);

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-white mb-8">Aulas Exclusivas</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Player de Vídeo */}
          <div className="lg:col-span-2">
            {selectedVideo ? (
              <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
                <iframe
                  src={`https://www.youtube.com/embed/${selectedVideo.id}`}
                  title={selectedVideo.title}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            ) : (
              <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
                <p className="text-gray-400">Selecione um vídeo para começar</p>
              </div>
            )}
            {selectedVideo && (
              <div className="mt-4">
                <h2 className="text-xl font-bold text-white">{selectedVideo.title}</h2>
              </div>
            )}
          </div>

          {/* Lista de Vídeos */}
          <div className="bg-gray-900 rounded-lg p-4">
            <h3 className="text-lg font-bold text-white mb-4">Lista de Aulas</h3>
            <div className="space-y-2">
              {videos.map((video) => (
                <button
                  key={video.id}
                  onClick={() => setSelectedVideo(video)}
                  className={`w-full p-3 rounded-lg flex items-start gap-3 transition-colors ${
                    selectedVideo?.id === video.id
                      ? 'bg-red-600'
                      : 'bg-gray-800 hover:bg-gray-700'
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-32 h-20 rounded object-cover"
                    />
                    {selectedVideo?.id !== video.id && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
                        <Play className="w-8 h-8 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-white truncate">
                      {video.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span className="text-xs text-gray-400">{video.duration}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
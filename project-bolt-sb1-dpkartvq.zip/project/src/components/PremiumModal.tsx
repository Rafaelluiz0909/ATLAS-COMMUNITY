import React from 'react';
import { X, Crown } from 'lucide-react';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function PremiumModal({ isOpen, onClose }: PremiumModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg max-w-md w-full border border-red-600 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X size={24} />
        </button>

        <div className="p-6">
          <div className="text-center mb-6">
            <Crown className="w-16 h-16 text-red-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Upgrade para Premium</h2>
            <p className="text-gray-400">Desbloqueie todos os recursos exclusivos</p>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-3 text-gray-300">
              <Crown size={20} className="text-red-600" />
              <span>Acesso a todas as ferramentas premium</span>
            </div>
            <div className="flex items-center gap-3 text-gray-300">
              <Crown size={20} className="text-red-600" />
              <span>Suporte prioritário</span>
            </div>
            <div className="flex items-center gap-3 text-gray-300">
              <Crown size={20} className="text-red-600" />
              <span>Atualizações antecipadas</span>
            </div>
          </div>

          <div className="text-center mb-6">
            <div className="text-3xl font-bold text-white mb-2">
              R$ 97,00
              <span className="text-sm text-gray-400">/trimestre</span>
            </div>
            <p className="text-sm text-gray-400">Acesso a todos os recursos por 3 meses</p>
          </div>

          <a
            href="https://wa.me/5547999773975?text=Quero%20o%20plano%20pro%20da%20atlas%20community%20de%2097,00"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors inline-block text-center"
            onClick={onClose}
          >
            Adquirir Agora
          </a>
          
          <p className="text-xs text-gray-400 text-center mt-4">
            Após o pagamento, seu acesso será liberado manualmente pela nossa equipe
          </p>
        </div>
      </div>
    </div>
  );
}
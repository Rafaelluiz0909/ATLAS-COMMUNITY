import React, { useState, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Lock, Mail } from 'lucide-react';
import { AtlasLogo } from './AtlasLogo';

interface AuthFormProps {
  isRegister?: boolean;
}

export function AuthForm({ isRegister = false }: AuthFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleAuth = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      if (isRegister) {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/login`,
            data: {
              email
            }
          }
        });

        if (signUpError) throw signUpError;

        if (data?.user) {
          setSuccess('Conta criada com sucesso! Você já pode fazer login.');
          setTimeout(() => {
            navigate('/login', { replace: true });
          }, 2000);
        }
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });

        if (signInError) throw signInError;
      }
    } catch (err: any) {
      console.error('Erro de autenticação:', err);
      let errorMessage = 'Ocorreu um erro durante a autenticação.';
      
      if (err.message.includes('Email not confirmed')) {
        errorMessage = 'Por favor, confirme seu email antes de fazer login.';
      } else if (err.message.includes('Invalid login credentials')) {
        errorMessage = 'Email ou senha incorretos.';
      } else if (err.message.includes('User already registered')) {
        errorMessage = 'Este email já está registrado.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [email, password, isRegister, loading, navigate]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <AtlasLogo className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-red-600">ATLAS COMMUNITY</h1>
        </div>

        <form onSubmit={handleAuth} className="bg-gray-900 shadow-xl rounded-lg px-8 pt-6 pb-8 mb-4 border border-red-600">
          <h2 className="text-2xl font-bold text-center mb-6 text-white">
            {isRegister ? 'Criar Conta' : 'Login'}
          </h2>
          
          {error && (
            <div className="mb-4 p-3 bg-red-600/20 border border-red-600 rounded text-red-500 text-sm">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-600/20 border border-green-600 rounded text-green-500 text-sm">
              {success}
            </div>
          )}

          <div className="mb-4">
            <label className="block text-red-500 text-sm font-bold mb-2" htmlFor="email">
              Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 bg-gray-800 appearance-none border border-gray-700 rounded w-full py-2 px-3 text-gray-200 leading-tight focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
                required
                placeholder="seu@email.com"
                disabled={loading}
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-red-500 text-sm font-bold mb-2" htmlFor="password">
              Senha
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 bg-gray-800 appearance-none border border-gray-700 rounded w-full py-2 px-3 text-gray-200 leading-tight focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
                required
                placeholder="Sua senha"
                minLength={6}
                disabled={loading}
              />
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 transition-colors disabled:opacity-50"
            >
              {loading ? 'Carregando...' : isRegister ? 'Criar Conta' : 'Entrar'}
            </button>
            
            <Link
              to={isRegister ? '/login' : '/register'}
              className="text-red-500 hover:text-red-400 text-sm text-center transition-colors"
            >
              {isRegister ? 'Já tem uma conta? Faça login' : 'Não tem uma conta? Cadastre-se'}
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}